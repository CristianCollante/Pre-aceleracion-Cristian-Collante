package com.example.pre_aceleracinalkemyandroid.data

class RepositoryResult<T>(
    val data : T? = null,
    val errorMessage : String? = null
)