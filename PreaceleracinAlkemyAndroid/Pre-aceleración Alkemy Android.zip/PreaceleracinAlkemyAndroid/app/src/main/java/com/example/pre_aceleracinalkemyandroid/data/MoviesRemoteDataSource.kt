package com.example.pre_aceleracinalkemyandroid.data

import com.example.pre_aceleracinalkemyandroid.BuildConfig
import retrofit2.Response
import retrofit2.awaitResponse
import java.lang.Exception

class MoviesRemoteDataSource {

    suspend fun getMovies() : PopularMoviesDb?{
        val service = RetrofitService.instance.create(MoviesService::class.java)
            .getPopularMovies(BuildConfig.KEY)

        try {
            val response : Response<PopularMoviesDb> = service.awaitResponse()
            val moviesDb = response.body()
            return moviesDb
        }
        catch (e : Exception){
            return null
        }
    }

    suspend fun getDetails(movieId : Int) : DetailDb?{
        val service = RetrofitService.instance.create(DetailService::class.java)
            .getDetail(movieId, BuildConfig.KEY)

        try {
            val response : Response<DetailDb> = service.awaitResponse()
            val detailDb = response.body()
            return detailDb
        }
        catch (e : Exception){
            return null
        }
    }
}