package com.example.pre_aceleracinalkemyandroid.views

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pre_aceleracinalkemyandroid.data.MovieDb
import com.example.pre_aceleracinalkemyandroid.data.MoviesRepository
import kotlinx.coroutines.launch

class MoviesViewMoldel (
    private val moviesRepository : MoviesRepository
) : ViewModel(){

    val movies = MutableLiveData<List<MovieDb>>()
    val loading = MutableLiveData(false)
    val error = MutableLiveData<String?>(null)

    fun loadMovies(){
        loading.value = true
        viewModelScope.launch {
            val result = moviesRepository.getMovies()
            if(result != null){
                movies.value = result.results
            }
            loading.value = false
        }
    }
}